<?php

$dbhost="localhost";
$dbuser="root";
$dbpass="";
$db="euresia";

$con= new mysqli ($dbhost,$dbuser,$dbpass,$db);

if ($con->connect_error) {
	echo "";
}
else{

	echo "";

}


?>