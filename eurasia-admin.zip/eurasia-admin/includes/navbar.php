 <body>

<style type="text/css"> 
  .dropdown:hover>.dropdown-menu
  {
   display:inline-block;
   position: relative;
   box-shadow: 0px 8px 10px 0px rgba(0,0,0,0.5);
   background-color:  ;
  }
</style>
  
 <!-- Sidebar -->
     <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar" style="color:black;">

      <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
        
        </div>
        <div class="sidebar-brand-text mx-3">Eurasia Admin</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Fabric Details
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
     <li class="nav-item">
        <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseone" aria-expanded="true" aria-controls="collapseone">
          <i class="fas fa-fw fa-cog"></i>
          <span>Design</span>
        </a>
        <div id="collapseone" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded border border-dark" style="font-size:12px;">
      <a class="collapse-item font-weight-bold" href="design.php"> Add Design Details</a>
      <a class="collapse-item font-weight-bold" href="viewdesign.php"> View Design Details</a>
          </div>
        </div>
      </li>
      

       <!-- Nav Item - Utilities Collapse Menu -->
     <li class="nav-item dropdown no-arrow">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-cog"></i>
          <span>Raw Material</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded border border-dark font-weight-bold">
           <!-- <h6 class="collapse-header">Categories:</h6>-->

          
  <span class="btn-group dropdown">
  <a type="button" class="btn dropdown-toggle font-weight-bold" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:14px;">
   Fabrics
  </a>
  <div class="dropdown-menu border border-dark" style="font-size:12px; color:black;">
    <a class="dropdown-item font-weight-bold" href="Fabrics.php" style="color: black;">Add Fabric Details</a>
    <a class="dropdown-item font-weight-bold" href="viewfabrics.php" style="color: black;">View Fabric Details</a>
  </div>
  </span>
<br>
  <span class="btn-group dropdown">
  <a type="button" class="btn dropdown-toggle font-weight-bold" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:14px;">
  Piping Fabric
  </a>
  <div class="dropdown-menu border border-dark" style="font-size:12px;color: black;">
    <a class="dropdown-item font-weight-bold" href="fabricpiping.php" style="color: black;">Add Piping Fabric Details</a>
    <a class="dropdown-item font-weight-bold" href="view-pipingfabric.php" style="color: black;">View Piping Fabric Details</a>
  </div>
  </span>
<br>
  <span class="btn-group dropdown">
  <a type="button" class="btn dropdown-toggle font-weight-bold" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:14px;">
   Zipper
  </a>
  <div class="dropdown-menu border border-dark " style="font-size:12px;color: black;">
    <a class="dropdown-item font-weight-bold" href="zipper.php" style="color: black;">
    Add Zipper Details</a>
    <a class="dropdown-item font-weight-bold" href="viewzipper.php" style="color: black;">View Zipper Details</a>
  </div>
  </span>
<br>
  <div class="btn-group dropdown">
  <a type="button" class="btn dropdown-toggle font-weight-bold" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:14px;">
  Tag 
  </a>
  <div class="dropdown-menu border border-dark" style="font-size:12px;color: black;">
    <a class="dropdown-item font-weight-bold" href="tag.php" style="color: black;">Add Tag Details</a>
    <a class="dropdown-item font-weight-bold" href="tagview.php" style="color: black;">View Tag Details</a>
  </div>
  </div>
<br>

  <span class="btn-group dropdown">
  <a type="button" class="btn dropdown-toggle font-weight-bold" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:14px;">
  Thread
  </a>
  <div class="dropdown-menu border border-dark " style="font-size:12px;color: black;">
    <a class="dropdown-item font-weight-bold" href="thread.php" style="color: black;">Add Thread Details</a>
    <a class="dropdown-item font-weight-bold" href="viewthread.php" style="color: black;">View Thread Details</a>
  </div>
  </span>

<br>
  <span class="btn-group dropdown">
  <a type="button" class="btn dropdown-toggle font-weight-bold" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:14px;">
 Piping Rope
  </a>
  <div class="dropdown-menu border border-dark font-weight-bold" style="font-size:12px;color: black;">
    <a class="dropdown-item font-weight-bold" href="pipingrole.php" style="color: black;">Add Piping Rope Details</a>
    <a class="dropdown-item font-weight-bold" href="viewpipingrope.php" style="color: black;">View Piping Rope Details</a>
  </div>
  </span>
   
            <!---<a class="collapse-item" href="backingpaper.php">Backing Paper</a>
            <a class="collapse-item" href="tapes.php">Both-Sided Tapes</a>--->
      
      
          </div>
        </div>
      </li>

    
    <!-- production- Pages Collapse Menu -->
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-wrench" style="font-size:14px;"></i>
          <span>Production</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded border border-dark font-weight-bold" style="font-size:12px;">
          <!--  <h6 class="collapse-header">Production Details</h6>-->
            <a class="collapse-item" href="fabricdetail.php" style="color: black;">Add Production Details</a>
             <a class="collapse-item" href="viewproduct.php" style="color: black;">View Production Details</a>
          </div>
        </div>
      </li>
    
    <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
          <i class="fas fa-fw fa-cog"></i>
          <span>Stiching</span>
        </a>
        <div id="collapseThree" class="collapse order border-dark" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded border border-dark">
            <a class="collapse-item font-weight-bold" href="stich.php">Stiching Details</a>
          </div>
        </div>
      </li>
    
    <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsefour" aria-expanded="true" aria-controls="collapsefour">
          <i class="fas fa-fw fa-cog"></i>
          <span>Embroidery</span>
        </a>
        <div id="collapsefour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded border border-dark">
            <a class="collapse-item font-weight-bold" href="emb.php">Embroidery Details</a>
          </div>
        </div>
      </li>

       <!-- Divider -->
     <!-- <hr class="sidebar-divider">-->

    <!-- Heading -->
      <!--<div class="sidebar-heading">
        Addons
      </div>-->

        <!-- Nav Item - Pages Collapse Menu -->
    <!--  <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Account</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Login Screens:</h6>
            <a class="collapse-item" href="#">Login</a>
            <a class="collapse-item" href="#">Register</a>
            <a class="collapse-item" href="#">Forgot Password</a>
            <div class="collapse-divider"></div>
            
          </div>
        </div>
      </li>
    -->



      <!-- Nav Item - Charts -->
      <!----
      <li class="nav-item">
        <a class="nav-link" href="#">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span></a>
      </li>
      -------->

      <!-- Nav Item - Tables -->
     <!-- <li class="nav-item">
        <a class="nav-link" href="table.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Tables</span></a>
      </li>-->

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
	
	
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">f
    <i class="fas fa-angle-up"></i>
  </a>
  
  
  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

</body>